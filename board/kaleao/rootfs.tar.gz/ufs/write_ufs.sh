#!/bin/bash

dd if=set.bin.revb of=/dev/sdb skip=1
dd if=Image_noramfs of=/dev/sda seek=20480
dd if=./kmax-revb-ufs.dtb of=/dev/sda seek=18961
echo -e "n\np\n2\n2000\n+20G\nw\n" | fdisk /dev/sda
mkfs.ext4 /dev/sda2 -F
mount /dev/sda2 /mnt/
tar zxf ubuntu.tar.gz -C /mnt/
cp -raf /root/drivers /mnt/root/drivers

